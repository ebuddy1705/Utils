
#include "pch.h"
#include "ClassLibrary_CLI.h"



using namespace ClassLibraryCLI;




//Test callback function
foo mycb;
EXTERN_DLL_EXPORT void setcb(int a, foo cb)
{

	mycb = cb;
	//mycb(2 * a);

	Class1 ^instance = Class1::Instance();
	instance->StartExecThread();

	return ;
}

EXTERN_DLL_EXPORT float Add(float a, float b)
{
	Class1 ^instance = Class1::Instance();
	return instance->Add(a,b);
}


//EXTERN_DLL_EXPORT void setcb(int a, foo cb)
//{
//	return ;
//}
//
//
//int openDb() {
//	int rc;
//	char *error;
//
//	// Open Database
//	Console::WriteLine( "Opening MyDb.db ...");
//	sqlite3 *db;
//	rc = sqlite3_open("MyDb.db", &db);
//	if (rc)
//	{
//		cerr << "Error opening SQLite3 database: " << sqlite3_errmsg(db) << endl << endl;
//		sqlite3_close(db);
//		return 1;
//	}
//	else
//	{
//		cout << "Opened MyDb.db." << endl << endl;
//
//	}
//
//
//	// Execute SQL
//	cout << "Creating MyTable ..." << endl;
//	const char *sqlCreateTable = "CREATE TABLE MyTable (id INTEGER PRIMARY KEY, value STRING);";
//	rc = sqlite3_exec(db, sqlCreateTable, NULL, NULL, &error);
//	if (rc)
//	{
//		cerr << "Error executing SQLite3 statement: " << sqlite3_errmsg(db) << endl << endl;
//		sqlite3_free(error);
//	}
//	else
//	{
//		cout << "Created MyTable." << endl << endl;
//	}
//
//	// Execute SQL
//	cout << "Inserting a value into MyTable ..." << endl;
//	const char *sqlInsert = "INSERT INTO MyTable VALUES(NULL, 'A Value');";
//	rc = sqlite3_exec(db, sqlInsert, NULL, NULL, &error);
//	if (rc)
//	{
//		cerr << "Error executing SQLite3 statement: " << sqlite3_errmsg(db) << endl << endl;
//		sqlite3_free(error);
//	}
//	else
//	{
//		cout << "Inserted a value into MyTable." << endl << endl;
//	}
//
//	// Display MyTable
//	cout << "Retrieving values in MyTable ..." << endl;
//	const char *sqlSelect = "SELECT * FROM MyTable;";
//	char **results = NULL;
//	int rows, columns;
//	sqlite3_get_table(db, sqlSelect, &results, &rows, &columns, &error);
//	if (rc)
//	{
//		cerr << "Error executing SQLite3 query: " << sqlite3_errmsg(db) << endl << endl;
//		sqlite3_free(error);
//	}
//	else
//	{
//		// Display Table
//		for (int rowCtr = 0; rowCtr <= rows; ++rowCtr)
//		{
//			for (int colCtr = 0; colCtr < columns; ++colCtr)
//			{
//				// Determine Cell Position
//				int cellPosition = (rowCtr * columns) + colCtr;
//
//				// Display Cell Value
//				cout.width(12);
//				cout.setf(ios::left);
//				cout << results[cellPosition] << " ";
//			}
//
//			// End Line
//			cout << endl;
//
//			// Display Separator For Header
//			if (0 == rowCtr)
//			{
//				for (int colCtr = 0; colCtr < columns; ++colCtr)
//				{
//					cout.width(12);
//					cout.setf(ios::left);
//					cout << "-----";
//				}
//				cout << endl;
//			}
//		}
//	}
//	sqlite3_free_table(results);
//
//	// Close Database
//	cout << "Closing MyDb.db ..." << endl;
//	sqlite3_close(db);
//	cout << "Closed MyDb.db" << endl << endl;
//
//
//	return 0;
//}

namespace ClassLibraryCLI {
	float Class1::Add(float a, float b)
	{
		String ^hihi = "ClassLibraryCLI::Class1::Add";

		Console::WriteLine(hihi);
		return a + b;
	}


	void Class1::StartExecThread()
	{
		ThreadStart^ start = gcnew ThreadStart(this, &Class1::ExecThread);
		Thread^ thread = gcnew Thread(start);
		thread->Start();

	}

	void Class1::ExecThread()
	{
		int counter = 0;
		while (counter < 10)
		{
			mycb(counter);
			Thread::Sleep(100);
			counter++;
		}
	}
	

}
