package mycompany;


import com.sun.jna.Callback;
import com.sun.jna.Library;
import com.sun.jna.Native;




public interface JNA_CppCLIInterface extends Library {
	@SuppressWarnings("deprecation")
	final  JNA_CppCLIInterface INSTANCE = (JNA_CppCLIInterface) Native.loadLibrary("ClassLibrary_CLI.dll", JNA_CppCLIInterface.class);

    float Add(float a, float b);
    
    
  //Define callback interface
    public interface foo extends Callback {
        void invoke(int a);
    }
    // define an implementation of the callback interface
 	public static class fooCallbackImplementation implements foo {
 		@Override
 		public void invoke(int a) {
 			System.out.println("JNA_CppCLIInterface foo callback: " + a);
 		}
 	}

    void setcb(int a, foo cb);
    
}
