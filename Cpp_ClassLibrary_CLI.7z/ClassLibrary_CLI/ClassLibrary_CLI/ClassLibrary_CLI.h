#pragma once


#ifdef __cplusplus
extern "C" {
#endif
	
	#include "sqlite/sqlite3.h"
	#define EXTERN_DLL_EXPORT __declspec(dllexport)

#ifdef __cplusplus
}
#endif


using namespace System;
using namespace System::Threading;


namespace ClassLibraryCLI {
	public ref class Class1
	{
	private :
		static Class1 ^_instance = nullptr;

	public:
		//delegate instance
		static Class1 ^Instance()
		{
			if (_instance == nullptr) {
				_instance = gcnew  Class1();
				Console::WriteLine("Create instance");
			}
				
			return _instance;
		};

	

		float Add(float a, float b);


		//multi thread
		void StartExecThread();
		void ExecThread();

	};

	public class Class2
	{
	public:
		 Class2() {
			
		 }

		 
		
	};

}





#ifdef __cplusplus
extern "C" {
#endif
     

	//int openDb();

	//Test callback function
	typedef EXTERN_DLL_EXPORT int(*foo)(int);
	EXTERN_DLL_EXPORT void setcb(int a, foo cb);
	EXTERN_DLL_EXPORT float Add(float a, float b);




#ifdef __cplusplus
}
#endif