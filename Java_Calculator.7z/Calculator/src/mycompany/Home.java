package mycompany;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home {

	private JFrame frame;
	private JTextField textField_a;
	private JTextField textField_b;
	private ButtonGroup bg;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 575, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JLabel lblNewLabel = new JLabel("So a");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 42, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 39, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("So b");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 25, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, lblNewLabel);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Ket qua");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 58, SpringLayout.SOUTH, lblNewLabel_1);
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel_2, 0, SpringLayout.EAST, lblNewLabel);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField_a = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, textField_a, 47, SpringLayout.EAST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, textField_a, 0, SpringLayout.SOUTH, lblNewLabel);
		frame.getContentPane().add(textField_a);
		textField_a.setColumns(10);
		
		textField_b = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, textField_b, 0, SpringLayout.WEST, textField_a);
		springLayout.putConstraint(SpringLayout.SOUTH, textField_b, 0, SpringLayout.SOUTH, lblNewLabel_1);
		textField_b.setColumns(10);
		frame.getContentPane().add(textField_b);
		
		JPanel panel = new JPanel();
		springLayout.putConstraint(SpringLayout.NORTH, panel, 19, SpringLayout.SOUTH, textField_b);
		springLayout.putConstraint(SpringLayout.WEST, panel, 101, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, panel, -217, SpringLayout.EAST, frame.getContentPane());
		FlowLayout flowLayout = (FlowLayout) panel.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		frame.getContentPane().add(panel);
		
		JRadioButton rdbtnAdd = new JRadioButton("Add");
		panel.add(rdbtnAdd);
		springLayout.putConstraint(SpringLayout.NORTH, rdbtnAdd, 23, SpringLayout.SOUTH, textField_b);
		springLayout.putConstraint(SpringLayout.EAST, rdbtnAdd, 0, SpringLayout.EAST, textField_a);
		
		JRadioButton rdbtnSub = new JRadioButton("Sub");
		panel.add(rdbtnSub);
		
		JRadioButton rdbtnMul = new JRadioButton("Mul");
		panel.add(rdbtnMul);
		
		JRadioButton rdbtnDev = new JRadioButton("Dev");
		panel.add(rdbtnDev);
		
		JLabel lblResult = new JLabel("0");
		springLayout.putConstraint(SpringLayout.SOUTH, panel, -8, SpringLayout.NORTH, lblResult);
		springLayout.putConstraint(SpringLayout.WEST, lblResult, 0, SpringLayout.WEST, textField_a);
		springLayout.putConstraint(SpringLayout.SOUTH, lblResult, 0, SpringLayout.SOUTH, lblNewLabel_2);
		frame.getContentPane().add(lblResult);
		
		JButton btnCal = new JButton("Calculate");
		btnCal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					float a=Float.parseFloat(textField_a.getText()); 
					float b=Float.parseFloat(textField_b.getText()); 
					float result = 0;
					
					if(rdbtnAdd.isSelected()) {
						result = JNAApiInterface.INSTANCE.Add(a, b);
						lblResult.setText(String.valueOf(result));
					}else if(rdbtnSub.isSelected()) {
						result = JNAApiInterface.INSTANCE.Sub(a, b);
						lblResult.setText(String.valueOf(result));
					}else if(rdbtnMul.isSelected()) {
						result = JNAApiInterface.INSTANCE.Mul(a, b);
						lblResult.setText(String.valueOf(result));
					}else if(rdbtnDev.isSelected()) {
						if (b != 0) {
							result = JNAApiInterface.INSTANCE.Dev(a, b);
							lblResult.setText(String.valueOf(result));
						}else {
							lblResult.setText("b invalid");
						}
					}
				} finally {
					// TODO: handle finally clause
				}
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, btnCal, 18, SpringLayout.SOUTH, lblResult);
		springLayout.putConstraint(SpringLayout.WEST, btnCal, 0, SpringLayout.WEST, textField_a);
		frame.getContentPane().add(btnCal);
		
		bg = new ButtonGroup();
		bg.add(rdbtnAdd);
		bg.add(rdbtnSub);
		bg.add(rdbtnMul);
		bg.add(rdbtnDev);
		rdbtnAdd.setSelected(true);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				// instantiate a callback wrapper instance
				final JNAApiInterface.fooCallbackImplementation callbackImpl = new JNAApiInterface.fooCallbackImplementation();
				
				// pass the callback wrapper to the C library
				JNAApiInterface.INSTANCE.setcb(1, callbackImpl);

			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, btnNewButton, -26, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnNewButton, -194, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(btnNewButton);
		
		JButton btnOpenSqlite = new JButton("open sqlite");
		btnOpenSqlite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				System.out.println("open sqlite: " + JNAApiInterface.INSTANCE.initMyApp());
				
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, btnOpenSqlite, 30, SpringLayout.EAST, btnNewButton);
		springLayout.putConstraint(SpringLayout.SOUTH, btnOpenSqlite, 0, SpringLayout.SOUTH, btnNewButton);
		frame.getContentPane().add(btnOpenSqlite);
		
		JButton btnCPPCLI = new JButton("C++/CLI");
		btnCPPCLI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.out.println(JNA_CppCLIInterface.INSTANCE.Add(1, 2));
				
				
				// instantiate a callback wrapper instance
				final JNA_CppCLIInterface.fooCallbackImplementation callbackImpl2 = new JNA_CppCLIInterface.fooCallbackImplementation();
				
				// pass the callback wrapper to the C library
				JNA_CppCLIInterface.INSTANCE.setcb(1, callbackImpl2);
				
				
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, btnCPPCLI, 0, SpringLayout.WEST, btnOpenSqlite);
		springLayout.putConstraint(SpringLayout.SOUTH, btnCPPCLI, 0, SpringLayout.SOUTH, lblNewLabel_2);
		frame.getContentPane().add(btnCPPCLI);
		
	}
}
